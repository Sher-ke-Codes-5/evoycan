import './App.css';
import Home from './Components/Home/Home';

function App() {
  return (

    <Home/>
  );
}

export default App;
