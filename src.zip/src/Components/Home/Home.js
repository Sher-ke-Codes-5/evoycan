import React from "react";
import pic from "../../Assets/1.jpg";
import { useState } from "react";
const Home = () => {
  const [search, setSearch] = useState("");
  const [show, setShow] = useState(false);
  const handleSearch = (e) => {
    e.preventDefault();
    setSearch("");
  };
  const handleImage = () => {
    setShow(true);
  };
  return (
    <div className="flex flex-col w-full h-[1030px] bg-slate-200 ">
      <div className="flex ml-auto mr-auto flex-row">
        <form className="flex flex-row mt-2 mb-2" onSubmit={handleSearch}>
          <input
            type="text"
            id="search"
            name="search"
            value={search}
            autoComplete="off"
            placeholder="search Image"
            className="flex bg-slate-300 border-none focus:outline-none   placeholder:text-black rounded-full px-4 py-2"
            onChange={(e) => setSearch(e.target.value)}
          />
        </form>
      </div>
      {search && <img src={pic} alt="pic" className="max-w-full h-auto mt-4" />}
    </div>
  );
};

export default Home;
